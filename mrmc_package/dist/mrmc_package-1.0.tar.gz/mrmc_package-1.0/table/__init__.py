# table
# __init__.py

'''from .table1 import TABLE as TABLE_OLD
from .table2 import TABLE as TABLE_SIN
from .table3 import TABLE as TABLE_MUL
from .table4 import TABLE_POL


from .table2 import feff_table2, feff_table2s, feff_table3, feff_table4

__all__ = ['TABLE_SIN', 'TABLE_MUL', 'TABLE_POL']'''
